class Shape {
    constructor(sideArray=[]) {
        this.sides = sideArray;
    }

    perimeter = () => this.sides.length > 0 ? this.sides.reduce((total, num) => total + num) : 0;
}

class Rectangle extends Shape {
    constructor(length=0, width=0) {
        super();
        this.length = length;
        this.width = width;
        this.sides = [length, width, length, width];
    }

    area = () => this.length * this.width;
}

class Triangle extends Shape {
    constructor(sideA=0, sideB=0, sideC=0) {
        super();
        this.sideA = sideA;
        this.sideB = sideB;
        this.sideC = sideC;
        this.sides = [sideA, sideB, sideC];
    }

    area = () => Math.sqrt(
        ((this.sideA + this.sideB + this.sideC) / 2) * (
            ((this.sideA + this.sideB + this.sideC) / 2) - this.sideA
        ) * (
            ((this.sideA + this.sideB + this.sideC) / 2) - this.sideB
        ) * (
            ((this.sideA + this.sideB + this.sideC) / 2) - this.sideC
        )
    );
}

/* console.log(new Shape([5, 10]).perimeter());  // 15
console.log(new Shape([1, 2, 3, 4, 5]).perimeter()); // 15
console.log(new Shape().perimeter()); // 0 */

/* console.log(new Rectangle(4, 4).perimeter());  // 16
console.log(new Rectangle(4, 4).area());  // 16
console.log(new Rectangle(5, 5).perimeter()); // 20
console.log(new Rectangle(5, 5).area()); // 25
console.log(new Rectangle().perimeter()); // 0
console.log(new Rectangle().area()); // 0 */

/* console.log(new Triangle(3, 4, 5).perimeter());  // 12
console.log(new Triangle(3, 4, 5).area());  // 6
console.log(new Triangle().perimeter()); // 0
console.log(new Triangle().area()); // 0 */

const data = [ [3, 4], [5, 5], [3, 4, 5], [10], [] ];

{
    let shape;
    for (side of data) {
        switch (side.length) {
            case 2:
                const MyRectangle = new Rectangle(side[0], side[1]);
                if (MyRectangle.length === MyRectangle.width) {
                    shape = "Square";
                    printReturnLiteral(shape, side, MyRectangle);
                }
                else {
                    shape = "Rectangle";
                    printReturnLiteral(shape, side, MyRectangle);
                }
                break;
            case 3:
                const MyTriangle = new Triangle(side[0], side[1], side[2]);
                shape = "Triangle";
                printReturnLiteral(shape, side, MyTriangle);
                break;
            default:
                const MyShape = new Shape(side);
                printReturnLiteral("unsupported", side, MyShape);
        }
    }

    function printReturnLiteral(shape, sides, myShape) {
        let sOrNot;
        sides.length === 0 ? sOrNot = "s" : sOrNot = "";
        sides.length <= 1 ? console.log(`Shape with ${sides.length} side${sOrNot} unsupported`) : console.log(`${shape} with sides ${sides.toString()} has perimeter of ${myShape.perimeter()} and area of ${myShape.area()}`);
    }
}